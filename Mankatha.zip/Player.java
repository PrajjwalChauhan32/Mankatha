package ecc.Mankatha;

public class Player {
	private int player;
	private double betValue;
	private Card card;
	private String orientation;
	
	public Player() {}

	public Player(int player, double betValue, Card card, String orientation) {
		this.player = player;
		this.betValue = betValue;
		this.card = card;
		this.orientation = orientation;
	}

	public int getPlayer() {
		return player;
	}

	public void setPlayer(int player) {
		this.player = player;
	}

	public double getBetValue() {
		return betValue;
	}

	public void setBetValue(double betValue) {
		this.betValue = betValue;
	}

	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public String getOrientation() {
		return orientation;
	}

	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
}
