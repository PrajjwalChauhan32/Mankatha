package ecc.Mankatha;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Deck 
{
private List<Card> deck;
	
	public Deck() {
		this.deck = orderedListOfCards();
	}

	public List<Card> orderedListOfCards() {
		List<Card> deck = new ArrayList<Card>();
		
		for(int i=1;i<=4;i++) 
		{
			for(int j=1;j<=13;j++)
			{
				Card card = new Card(j,i);
				deck.add(card);
			}
		}
		return deck;
	}
	
	public List<Card> deckShuffle()
	{
		Collections.shuffle(deck);
		return deck;
	}
	

	public int deal(Map<Integer, Player> player)
	{
		List<Card> list = deckShuffle();
		int host = 0;
		
			Card in = list.remove(0);
			Card out = list.remove(0);
			
			for(Map.Entry<Integer, Player> element : player.entrySet()) 
			{
				if(element.getValue() == null) {
					host = element.getKey();
				}
				
				else if((in == element.getValue().getCard() && element.getValue().getOrientation().equalsIgnoreCase("IN"))
						|| (out == element.getValue().getCard() && element.getValue().getOrientation().equalsIgnoreCase("OUT"))) 
				{
					return element.getKey();
				}
			}
			return host;
	}
}