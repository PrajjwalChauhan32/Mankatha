package ecc.Mankatha;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class PlayGame
{
	public static void main(String[] args) {

		Deck d = new Deck();
		Scanner scan = new Scanner(System.in);	

		System.out.println("Start playing Mankatha");
		System.out.println("Number of players:");

		int numberOfPlayers = scan.nextInt();
		Random random = new Random();

		int host = random.nextInt(1,numberOfPlayers);
		boolean moveForward = true;

		while(moveForward) 
		{
			Map<Integer,Player> playerDetails = new LinkedHashMap<Integer,Player>();
			double betSum = 0;

			System.out.println("Host: "+"Player "+host);

			for(int i=1;i<=numberOfPlayers;i++) {
				if(host==i) {
					playerDetails.put(i, null);

				}else 
				{
					System.out.println("Player "+i+" Enter card details(space separated Rank and Suit) (Rank Suit)");
					int rank = scan.nextInt();int suit = scan.nextInt();

					Card c = new Card(rank,suit);
					System.out.println("Player "+i+" Enter your bet value");

					double bet = scan.nextDouble();
					System.out.println("Player "+i+" In Or Out ");

					String orientation = scan.next();
					Player p = new Player(i,bet,c,orientation);

					playerDetails.put(i, p);
					betSum += p.getBetValue();
				}
			}

			System.out.println("Player "+d.deal(playerDetails)+" wins and Bet amount is: "+betSum);
			System.out.println("Winner is the new Host ");
			System.out.println("To continue type Yes/To  stop type No");

			host = d.deal(playerDetails);

			if(!scan.next().equalsIgnoreCase("YES")) 
			{
				moveForward = false;
			}	
		}
		scan.close();;
	}
}